import React from 'react';
import Formcrud from '../Form/Formcrud';

const Product = () => {
    return (
        <div>
            <Formcrud></Formcrud>
            
        </div>
    );
};

export default Product;